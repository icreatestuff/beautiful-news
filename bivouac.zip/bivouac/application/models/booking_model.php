<?php

class Booking_model extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}
	
	// -----------------------------------------------------------------------------------------------------------------
	// Get Queries
	
	function get_sites()
	{
		$query = $this->db->get('sites');
		return $query;
	}
	
	function get_all()
	{
		$query = $this->db->get('accommodation');
		return $query;
	}
	
	function get_all_accommodation()
	{
		$query = $this->db->get('accommodation');
		return $query;
	}

	function get_all_from_accommodation_id($id)
	{
		$this->db->select('start_date, end_date, booking_id')->from('calendar')->where('accommodation_id', $id);
		$query = $this->db->get();
		return $query;
	}
	
	function get_accommodation($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('accommodation');
	}
	
	function get_bookings_within_two_weeks($id, $start, $end)
	{
		$sql = "SELECT start_date, end_date FROM calendar WHERE accommodation_id = " . $id . " AND DATE_FORMAT(calendar.start_date, '%Y-%m-%d 00:00:00') BETWEEN '" . $start . "' AND '" . $end . "' ORDER BY start_date";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function get_calendar_entries_between_dates($start, $end)
	{
		$sql = "SELECT accommodation_id FROM calendar WHERE DATE_FORMAT(calendar.start_date, '%Y-%m-%d 00:00:00') BETWEEN '" . $start . "' AND '" . $end . "'";
		return $this->db->query($sql);
	}
	
	function get_price()
	{
		$query = $this->db->get('pricing_schema');
		return $query;
	}
	
	function get_base_price($id)
	{
		$sql = "SELECT base_price, at.name FROM accommodation AS a, accommodation_types AS at WHERE a.id = " . $id . " AND a.type = at.id";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function get_additional_cost($id)
	{
		$sql = "SELECT additional_per_night_charge FROM accommodation WHERE id = " . $id;
		$query = $this->db->query($sql);
		return $query;
	}
	
	function get_total_beds($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('accommodation');
	}
	
	function get_guests()
	{
		$sql = "SELECT accommodation_ids, start_date, end_date, total_guests FROM bookings";
		return $this->db->query($sql);
	}
	
	function get_site_id($id)
	{
		$this->db->select('site_id');
		$this->db->where('id', $id);
		return $this->db->get('bookings');
	}
	
	function get_booking($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('bookings');
	}
	
	function get_bookings_next_two_weeks($start, $end)
	{
		$sql = "SELECT b.id, booking_ref, a.name, start_date, end_date, total_guests, first_name, last_name, total_price 
				FROM bookings AS b, accommodation AS a, contacts AS c 
				WHERE b.accommodation_ids = a.id
				AND b.contact_id = c.id
				AND DATE_FORMAT(start_date, '%Y-%m-%d 00:00:00') BETWEEN '" . $start . "' AND '" . $end . "' 
				ORDER BY start_date";
				
		return $this->db->query($sql);
	}
	
	function get_contact($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('contacts');
	}
	
	function get_extra_types()
	{
		return $this->db->get('extra_types');
	}
	
	function get_extras($type_id, $site_id)
	{
		$this->db->where('extra_type', $type_id);
		$this->db->where('site_id', $site_id);
		return $this->db->get('extras');
	}
	
	function get_booked_extras($id)
	{
		$sql = "SELECT extra_id, name, quantity, nights, purchased_extras.price FROM purchased_extras, extras WHERE purchased_extras.extra_id = extras.id AND purchased_extras.booking_id = " . $id;
		return $this->db->query($sql);
	}
	
	function get_public_holidays()
	{
		return $this->db->get('public_holidays');
	}
	
	// -----------------------------------------------------------------------------------------------------------------
	// Insert Queries
	
	function insert_booking_row($data)
	{
		$this->db->insert('bookings', $data);	
	}
	
	function insert_calendar_row($data)
	{
		$this->db->insert('calendar', $data);	
	}
	
	function insert_extra_purchases($data)
	{
		$this->db->insert_batch('purchased_extras', $data);	
	}
	
	function insert_contact_row($data)
	{
		$this->db->insert('contacts', $data);	
	}
	
	// -----------------------------------------------------------------------------------------------------------------
	// Update Queries
	
	function update_total_price($id, $price)
	{
		$sql = "UPDATE bookings SET total_price = '" . $price . "' WHERE id = " . $id;
		return $this->db->query($sql);
	}
	
	function add_booking_contact($id, $contact_id)
	{
		$sql = "UPDATE bookings SET contact_id = '" . $contact_id . "' WHERE id = " . $id;
		$this->db->query($sql);
	}
	
	function update_booking($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('bookings', $data);
	}
	
	// -----------------------------------------------------------------------------------------------------------------
	// Update Queries
	function delete_purchased_extras($booking_id)
	{
		$this->db->where('booking_id', $booking_id);
		$this->db->delete('purchased_extras');
	}
}	