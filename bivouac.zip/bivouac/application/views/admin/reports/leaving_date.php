<?php 
$data['title'] = "Leaving on given date";
$data['location'] = "reports";
$this->load->view("_includes/admin/head", $data); 
?>
	<h1>Show Bookings who are leaving on a given date</h1>
	
	<?php echo form_open('admin/reports/leaving_date', array('id' => 'leaving-date-form', 'class' => 'admin-form')); ?>
		<p>
			<label for="end_date">Select a leaving date (Monday or Friday)</label>
			<input type="text" name="end_date" id="end_date" class="date-input" value="" />
		</p>
		
		<input type="submit" name="submit" id="submit" value="Get bookings leaving on this date" />
	</form>
	
	<?php if (isset($bookings) && $bookings->num_rows > 0): ?>
	<table>
		<tbody>
			<?php foreach($bookings->result() as $booking): ?>
			<tr>
				<td><?php echo $booking->booking_ref; ?></td>
				<td><?php echo $booking->name; ?></td>
				<td><?php echo date('d/m/Y', strtotime($booking->start_date)); ?></td>
				<td><?php echo date('d/m/Y', strtotime($booking->end_date)); ?></td>
				<td><?php echo $booking->total_guests; ?></td>
				<td><?php echo $booking->first_name . " " . $booking->last_name; ?></td>
				<td><?php echo $booking->total_price; ?></td>
				<td><?php echo anchor('admin/bookings/overview/' . $booking->id, 'View Full Details', array('title' => 'View Full Booking Details')); ?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
		<thead>
			<tr>
				<th>Booking Ref</th>
				<th>Accommodation</th>
				<th>Arrival Date</th>
				<th>Departure Date</th>
				<th>Guests</th>
				<th>Contact Name</th>
				<th>Price</th>
				<th>Actions</th>
			</tr>
		</thead>
	</table>
	<?php else: ?>
	<p>There are no bookings leaving on the date you chose.</p>
	<?php endif; ?>
	
	<p><?php echo anchor('admin/reports/index/', 'View all reports', array('title' => 'View all reports')); ?></p>
<?php $this->load->view("_includes/admin/footer") ?>