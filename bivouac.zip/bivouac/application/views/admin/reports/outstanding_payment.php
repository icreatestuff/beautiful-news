<?php 
$data['title'] = "Bookings not fully paid";
$data['location'] = "reports";
$this->load->view("_includes/admin/head", $data); 
?>
	<h1>All bookings that have yet to be paid in full</h1>
	<?php if ($bookings->num_rows > 0): ?>
	<table>
		<tbody>
			<?php foreach($bookings->result() as $booking): ?>
			<tr>
				<td><?php echo $booking->booking_ref; ?></td>
				<td><?php echo $booking->name; ?></td>
				<td><?php echo date('d/m/Y', strtotime($booking->start_date)); ?></td>
				<td><?php echo date('d/m/Y', strtotime($booking->end_date)); ?></td>
				<td><?php echo $booking->total_guests; ?></td>
				<td><?php echo $booking->first_name . " " . $booking->last_name; ?></td>
				<td><?php echo $booking->total_price; ?></td>
				<td><?php echo anchor('admin/bookings/overview/' . $booking->id, 'View Full Details', array('title' => 'View Full Booking Details')); ?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
		<thead>
			<tr>
				<th>Booking Ref</th>
				<th>Accommodation</th>
				<th>Arrival Date</th>
				<th>Departure Date</th>
				<th>Guests</th>
				<th>Contact Name</th>
				<th>Price</th>
				<th>Actions</th>
			</tr>
		</thead>
	</table>
	<?php else: ?>
	<p>There are no bookings with outstanding payment</p>
	<?php endif; ?>
	
	<p><a href="#" class="export-xls" data-title="Outstanding Payment" data-model_function="get_outstanding_payment_bookings">Export .xls</a>
	<div id="result"></div>
	
	<p><?php echo anchor('admin/reports/index/', 'View all reports', array('title' => 'View all reports')); ?></p>
<?php $this->load->view("_includes/admin/footer") ?>