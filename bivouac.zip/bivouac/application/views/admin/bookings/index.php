<?php 
$data['title'] = "Booking System Administration";
$data['location'] = "admin";
$this->load->view("_includes/admin/head", $data); 
?>
<div id="container">
	<?php 
		$header_data['sites'] = $sites;
		$header_data['current_site'] = $current_site;
		$this->load->view("_includes/admin/header", $header_data);
	?>
	
	<div id="main" class="clearfix">
		<?php $this->load->view("_includes/admin/nav"); ?>		
		<div id="content">
			<h2>Overview</h2>
			
			<section>
				<h1>Bookings within 2 weeks of today!</h1>
				<?php if ($bookings->num_rows > 0): ?>
				<table>
					<tbody>
						<?php foreach($bookings->result() as $booking): ?>
						<tr>
							<td><?php echo $booking->booking_ref; ?></td>
							<td><?php echo $booking->name; ?></td>
							<td><?php echo date('d/m/Y', strtotime($booking->start_date)); ?></td>
							<td><?php echo date('d/m/Y', strtotime($booking->end_date)); ?></td>
							<td><?php echo $booking->total_guests; ?></td>
							<td><?php echo $booking->first_name . " " . $booking->last_name; ?></td>
							<td><?php echo $booking->total_price; ?></td>
							<td><?php echo anchor('admin/bookings/overview/' . $booking->id, 'View Full Details', array('title' => 'View Full Booking Details')); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
					<thead>
						<tr>
							<th>Booking Ref</th>
							<th>Accommodation</th>
							<th>Arrival Date</th>
							<th>Departure Date</th>
							<th>Guests</th>
							<th>Contact Name</th>
							<th>Price</th>
							<th>Actions</th>
						</tr>
					</thead>
				</table>
				<?php else: ?>
				<p>There are no bookings in the next 2 weeks</p>
				<?php endif; ?>
				<p><?php echo anchor('admin/reports/future_bookings/', 'View all future bookings', array('title' => 'View all future Bookings')); ?></p>
			</section>
		</div>
	</div>
</div>
<?php $this->load->view("_includes/admin/footer");