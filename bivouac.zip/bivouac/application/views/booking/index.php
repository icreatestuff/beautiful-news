<?php 
$data['title'] = "Book a holiday with us!";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>
	
	<h1>Book your holiday with us</h1>

	<div id="body">
		<p>Tell us when you would like your holiday to start and for how long and we'll find what accommodation we have available.</p>
	</div>

	
	<?php echo form_open('booking/index', array('id' => 'booking-form', 'class' => 'booking-form')); ?>
		<input type="hidden" name="site_id" id="site_id" value="1" />
		<input type="hidden" name="start_date" id="start_date" value="" />
		<input type="hidden" name="total_price" id="total_price" value="" />
	
		<div id="calendar"></div>
		
		<p>
			<label for="duration">How many nights do you wish to stay?</label>
			<select name="duration" id="duration">
				<option value="">Please select an arrival date from the calendar</option>
			</select>
		</p>
	
		<ul id="accommodation" class="accommodation-list"></ul>
	
		<p>
			<label for="total_guests">How many people will be staying?</label>
			<select name="total_guests" id="total_guests">
				<option value="1">1</option>
			</select>
		</p>
		
		<p>
			<input type="submit" name="submit" id="submit" value="Book these dates" />
		</p>
	</form>
	
</div>
<?php $this->load->view("_includes/frontend/footer");