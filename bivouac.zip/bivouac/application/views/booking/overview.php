<?php 
$data['title'] = "Booking Overview";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>
	<h1>Booking Details Overview</h1>
	<p>Hello <b><?php echo $user['screen_name']; ?></b>.<br />Please check all the details below about your booking before proceeding to pay. Thank you.</p>

	<div class="content" id="overview">
		<div class="booking-details overview-section">
			<?php 
				if ($booking_details->num_rows() > 0):
					$booking = $booking_details->row();
					$total_guests = $booking->total_guests;
			?>
				<h3>Booking Details</h3>
				<p>
					<b>Booking Reference No.</b> <?php echo $booking->booking_ref; ?><br />
					<b>Arrival Date.</b> <?php echo date('l dS M Y', strtotime($booking->start_date)); ?><br />
					<b>Departure Date.</b> <?php echo date('l dS M Y', strtotime($booking->end_date)); ?><br />
					<b>Total Price.</b> &pound;<?php echo $booking->total_price; ?>
				</p>		
			<?php
				endif;
			?>
			</div>
			
			<div class="contact-details overview-section">
			<?php 
				if ($contact_details->num_rows() > 0):
					$contact = $contact_details->row();
			?>
				<h3>Contact Details</h3>
				<p>
					<b>Name.</b> <?php echo  $contact->title . " " . $contact->first_name . " " . $contact->last_name; ?><br />
					<b>Email Address.</b> <?php echo $contact->email_address; ?><br />
					<b>Daytime Contact Number.</b> <?php echo $contact->daytime_number; ?>
					<?php if (!empty($contact->mobile_number)): ?>
					<b>Mobile Number.</b> <?php echo $contact->mobile_number; ?>
					<?php endif; ?>
				</p>
				
				<p>
					<b>Address.</b><br />
					<?php echo $contact->house_name; ?><br />
					<?php echo $contact->address_line_1; ?><br />
					<?php if (!empty($contact->address_line_2)) { echo $contact->address_line_2 . "<br />"; } ?>
					<?php echo $contact->city; ?><br />
					<?php echo $contact->county; ?><br />
					<?php echo $contact->post_code; ?>
				</p>	
			<?php
				endif;
			?>
			</div>
			
			<div class="accommodation-details overview-section">
			<?php 
				if ($accommodation_details->num_rows() > 0):
					$accommodation = $accommodation_details->row();
			?>
				<h3>Accommodation Details</h3>
				<p>
					<b>Accommodation Unit.</b> <?php echo $accommodation->name; ?><br />
					<b>Number of Guests.</b> <?php echo $total_guests; ?>
				</p>	
			<?php
				endif;
			?>
			</div>
			
			<div class="extras-details overview-section">
			<h3>Extras</h3>
			<p><?php echo anchor('booking/edit_extras/' . $booking->id, 'Add/Edit Extras on this booking', array('title' => 'Add/Edit Extras associated with this booking')); ?></p>
			<?php if ($extras->num_rows() > 0): ?>
				<table>
					<tbody>
					<?php foreach ($extras->result() as $extra): ?>
						<tr>
							<td><?php echo $extra->name; ?></td>
							<td><?php echo $extra->quantity; ?></td>
							<td><?php if (!empty($extra->nights)) { echo $extra->nights; }?></td>
							<td><?php echo $extra->price; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<thead>
						<tr>
							<th>Name</th>
							<th>Quantity</th>
							<th>Days/Nights</th>
							<th>Price (&pound;)</th>
						</tr>
					</thead>
				</table>		
			<?php endif; ?>
		</div>
	</div>	
</div>
<?php $this->load->view("_includes/frontend/footer");