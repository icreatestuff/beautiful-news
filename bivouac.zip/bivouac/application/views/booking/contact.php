<?php 
$data['title'] = "Fill in primary booking contact details!";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>

	<h1>Primary Booking Contact Details</h1>
	<p>Please fill in the details for the primary booking contact.</p>

	<div class="content" id="contact">
		<?php 
			$is_logged_in = $this->session->userdata('is_logged_in');
			if (isset($is_logged_in) && $is_logged_in === TRUE):
		?>
		
		<p>We have used your saved contact details for this booking. If you would like to change your contact details please head over to your account.</p>
		
		<?php echo anchor('booking/overview', 'Continue to booking overview', array('title' => 'See all booking details')); ?>
		
		<?php else: ?>
		
			<?php echo form_open('booking/contact/' . $booking_id, array('id' => 'contact-booking-form', 'class' => 'booking-form')); ?>
				<input type="hidden" name="booking_id" id="booking_id" value="<?php echo $booking_id; ?>" />			
				
				<p>					
					<label for="title">Title *</label>
					<select id="title" name="title">
						<option value="--">--</option>
						<option value="Mr">Mr</option>
						<option value="Mrs">Mrs</option>
						<option value="Miss">Miss</option>
						<option value="Ms">Ms</option>
					</select>
				</p>
				
				<p>
					<label for="first_name">First Name *</label>
					<input type="text" name="first_name" id="first_name" value="<?php echo set_value('first_name'); ?>" />
				</p>
				
				<p>
					<label for="last_name">Surname *</label>
					<input type="text" name="last_name" id="last_name" value="<?php echo set_value('last_name'); ?>" />
				</p>
				
				<p>
					<label for="birth_day">Date of Birth *</label>
					<select id="birth_day" name="birth_day" class="dob">
						<option value="--">Day</option>
						<?php for ($i=1; $i<=31; $i++): ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
						<?php endfor; ?>
					</select>
					
					<select id="birth_month" name="birth_month" class="dob">
						<option value="--">Month</option>
						<?php for ($i=1; $i<=12; $i++): ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
						<?php endfor; ?>
					</select>
					
					<select id="birth_year" name="birth_year" class="dob">
						<option value="--">Year</option>
						<?php 
							$year = date('Y'); 
							for ($i=1; $i<=100; $i++): 
						?>
						<option value="<?php echo $year; ?>"><?php echo $year; ?></option>
						<?php 
							$year--;
							endfor; 
						?>
					</select>
				</p>
				
				<p>
					<label for="house_name">House Number/Name *</label>
					<input type="text" name="house_name" id="house_name" value="<?php echo set_value('house_name'); ?>" />
				</p>
				
				<p>
					<label for="address_line_1">Address Line 1 *</label>
					<input type="text" name="address_line_1" id="address_line_1" value="<?php echo set_value('address_line_1'); ?>" />
				</p>
				
				<p>
					<label for="address_line_2">Address Line 2</label>
					<input type="text" name="address_line_2" id="address_line_2" value="<?php echo set_value('address_line_2'); ?>" />
				</p>
				
				<p>
					<label for="city">Town/City *</label>
					<input type="text" name="city" id="city" value="<?php echo set_value('city'); ?>" />
				</p>
				
				<p>
					<label for="county">County *</label>
					<input type="text" name="county" id="county" value="<?php echo set_value('county'); ?>" />
				</p>
				
				<p>
					<label for="post_code">Postcode *</label>
					<input type="text" name="post_code" id="post_code" value="<?php echo set_value('post_code'); ?>" />
				</p>
				
				<p>
					<label for="daytime_number">Daytime Telephone Number *</label>
					<input type="text" name="daytime_number" id="daytime_number" value="<?php echo set_value('daytime_number'); ?>" />
				</p>
				
				<p>
					<label for="mobile_number">Mobile Number</label>
					<input type="text" name="mobile_number" id="mobile_number" value="<?php echo set_value('mobile_number'); ?>" />
				</p>
	
				<p>
					<label for="email_address">Email Address * (We will send booking confirmation to this address)</label>
					<input type="text" name="email_address" id="email_address" value="<?php echo set_value('email_address'); ?>" />
				</p>	
				
				<p>
					<label for="newsletter_registration">Would you like to receive our email newsletters?</label>
					<input type="checkbox" name="newsletter_registration" id="newsletter_registration" value="y" />
				</p>
				
				<p>
					<label for="terms_and_conditions">I have read and agree to the <a href="#">terms and conditions</a></label>
					<input type="checkbox" name="terms_and_conditions" id="terms_and_conditions" value="y" />
				</p>	
				
				<hr />
				<p>To be able to manage and refer back to your booking in the future you will need to enter a password.</p>
				<p>
					<label for="password">Password</label>
					<input type="password" name="password" id="password" value="" />
				</p>
				
				<p>
					<label for="password_confirmation">Password confirmation (Enter the same password as you did in the previous field)</label>
					<input type="password" name="password_confirmation" id="password_confirmation" value="" />
				</p>								
	
				<ul class="errors">
					<?php echo validation_errors('<li>', '</li>'); ?>
				</ul>
				
				<input type="submit" id="submit" name="submit" value="Continue to booking overview" />
			</form>
		<?php endif; ?>
	</div>	
	
</div>
<?php $this->load->view("_includes/frontend/footer");