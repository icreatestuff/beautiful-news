<?php 
$data['title'] = "Login to your account";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<h1>Login to your account</h1>

	
	<?php $this->load->view("_includes/frontend/login_form"); ?>
	
	
	
</div>
<?php $this->load->view("_includes/frontend/footer");