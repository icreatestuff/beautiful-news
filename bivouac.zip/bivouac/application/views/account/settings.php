<?php 
$data['title'] = "Account Settings";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>

	<h1>My Account</h1>
	
	<div class="account-panel clearfix">
		<ul class="account-nav">
			<li><?php echo anchor('/account/bookings', 'Bookings', array('title' => 'View your bookings')); ?></li>
			<li><?php echo anchor('/account/settings', 'Account Settings', array('title' => 'Update your email address and password')); ?></li>
			<li><?php echo anchor('/account/address', 'Account Address', array('title' => 'Update your address')); ?></li>
		</ul>
		
		<div class="account-section-content">
			<h2>Account Settings</h2>
			
			<?php echo form_open('account/settings', array('account-settings-form')); ?>
					<p>
						<label for="email_address">Email Address *</label>
						<input type="text" name="email_address" id="email_address" value="<?php echo $member->email_address; ?>" />
					</p>
					
					<p>
						<label for="password">New Password</label>
						<input type="password" name="password" id="password" value="" />
					</p>
					
					<p>
						<label for="password_confirmation">Password Confirmation</label>
						<input type="password" name="password_confirmation" id="password_confirmation" value="" />
					</p>
					
					<ul class="errors">
						<?php echo validation_errors('<li>', '</li>'); ?>
					</ul>
					
					<input type="submit" name="submit" id="submit" value="Update settings" />
				
			<?php echo form_close(); ?>
		</div>
	</div>
	
</div>
<?php $this->load->view("_includes/frontend/footer");