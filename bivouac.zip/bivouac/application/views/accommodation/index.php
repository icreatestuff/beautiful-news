<?php 
$data['title'] = "See our accommodation";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>

	<h1>Accommodation List Page</h1>

	<div id="body">
		<p>Listed below is all of our accommodation. Find the perfect space for your holiday or short break.</p>
	</div>
	
	<ul class="accommodation-list">
		<?php if ($query->num_rows() > 0): ?>
			<?php foreach ($query->result() as $row): ?>
				<li>
					<?php if (!empty($row->photo_1)): ?>
						<img src="<?php echo base_url() . 'images/accommodation/' . $row->photo_1; ?>" width="100" alt="<?php echo $row->name; ?> Primary Photo" />
					<?php endif; ?>
					<div>
						<h3><a href="<?php echo base_url(); ?>index.php/accommodation/unit/<?php echo $row->id ?>" title="View full accommodation detail"><?php echo $row->name; ?></a></h3>
						<p><b>Bedrooms: </b><?php echo $row->bedrooms; ?> | <b>Sleeps: </b><?php echo $row->sleeps; ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		<?php endif; ?>
	</ul>
	
	
</div>
<?php $this->load->view("_includes/frontend/footer");