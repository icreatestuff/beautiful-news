<?php 
$data['title'] = $accommodation->name . " | Bivouac Accommodation";
$this->load->view("_includes/frontend/head", $data); 
?>
<div id="container">
	<?php $this->load->view("_includes/frontend/header"); ?>
	<h1><?php echo $accommodation->name; ?></h1>
	
	<div class="unit_info">
		<?php if (!empty($accommodation->photo_1)): ?>
			<img src="<?php echo base_url() . 'images/accommodation/' . $accommodation->photo_1; ?>" width="400" alt="<?php echo $accommodation->name; ?> Primary Photo" />
		<?php endif; ?>
			
		<h3><?php echo $accommodation->name; ?></h3>
		<p><b>Bedrooms: </b><?php echo $accommodation->bedrooms; ?> | <b>Sleeps: </b><?php echo $accommodation->sleeps; ?></p>

		<p><?php echo nl2br($accommodation->description); ?></p>
		
		<ul>
			<?php 
				$amenities = explode("\n", $accommodation->amenities); 
				foreach ($amenities as $item):
			?>
				<li><?php echo $item; ?></li>
			<?php endforeach; ?>
		</ul>
		
		<?php echo form_open('accommodation/unit/' . $accommodation->id, array('id' => 'accommodation-booking-form', 'class' => 'booking-form')); ?>
			<input type="hidden" name="site_id" id="site_id" value="<?php echo $accommodation->site_id; ?>" />
			<input type="hidden" name="accommodation_ids" id="accommodation_id" value="<?php echo $accommodation->id; ?>" />
			<input type="hidden" name="start_date" id="start_date" value="" />
			<input type="hidden" name="total_price" id="total_price" value="" />
		
			<div id="accommodation-calendar" data-accom-id="<?php echo $accommodation->id; ?>" data-type="<?php echo $accommodation->type_name; ?>"></div>
			
			<p>
				<label for="duration">How many nights do you wish to stay?</label>
				<select name="duration" id="duration">
					<option value="">Please select an arrival date from the calendar</option>
				</select>
			</p>
		
			<p>
				<label for="total_guests">How many people will be staying?</label>
				<select name="total_guests" id="total_guests">
					<?php for ($i=1; $i<=$accommodation->sleeps; $i++): ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
					<?php endfor; ?>
				</select>
			</p>
			
			<p>
				<input type="submit" name="submit" id="submit" value="Book these dates" />
			</p>
		</form>
	</div>
	
	
</div>
<?php $this->load->view("_includes/frontend/footer");