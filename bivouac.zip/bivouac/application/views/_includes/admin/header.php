<header> 
	<h1>The Bivouac Booking System Control Panel</h1>
	<ul id="sites-list">
		<li>
			<?php foreach ($current_site->result() as $row): ?>
				<?php echo $row->name; ?>
			<?php endforeach; ?>
			<ul>
				<?php	if ($sites->num_rows() > 0): ?>
					<?php foreach ($sites->result() as $row):	?>
						<li><a href="#" data-id="<?php echo $row->id; ?>" class="change-site"><?php echo $row->name; ?></li>
					<?php endforeach; ?>
				<?php endif; ?>
				<li class="add-site"><?php echo anchor('admin/sites/new_site/', 'Add Site', array('title' => 'Add Site')); ?></li>
				<li><?php echo anchor('admin/sites/index/', 'Edit Sites', array('title' => 'Edit Site Information')); ?></li>
			</ul>
		</li>
	</ul>
</header>