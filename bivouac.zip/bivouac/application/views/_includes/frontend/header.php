<header> 
	<?php if ($this->session->userdata('is_logged_in') === TRUE): ?>
		<p> 
			Hello <b><?php echo $this->session->userdata('screen_name'); ?></b><br />
			<?php echo anchor('account/logout', 'Log out'); ?>
		</p>
	<?php endif; ?>
	<ul>
		<li>
			<?php echo anchor('/account/bookings', 'My Account', array('title' => 'Log in to your account')); ?>		
		</li>
	</ul>
</header>