<aside>
	<h2>Navigation</h2>
	<nav> 
		<ul id="nav"> 
			<li> 
				<?php 
					if ($location === "admin")
					{ 
						echo anchor('admin/admin', 'Overview', array('title' => 'View bookings overview', 'class' => 'active')); 
					}
					else
					{
						echo anchor('admin/admin', 'Overview', array('title' => 'View bookings overview'));
					}	
				?> 
			</li> 
			<li> 
				<?php 
					if ($location === "accommodation")
					{
						echo anchor('admin/accommodation', 'Accommodation', array('title' => 'Manage accommodation', 'class' => 'active'));
					}
					else
					{
						echo anchor('admin/accommodation', 'Accommodation', array('title' => 'Manage accommodation'));
					}
				?>
			</li> 
			<li> 
				<?php 
					if ($location === "extras")
					{
						echo anchor('admin/extras', 'Extras', array('title' => 'Manage Extras', 'class' => 'active'));
					}
					else
					{
						echo anchor('admin/extras', 'Extras', array('title' => 'Manage Extras')); 
					}		
				?>
			</li> 
			<li> 
				<?php 
					if ($location === "pricing")
					{
						echo anchor('admin/pricing', 'Pricing', array('title' => 'Manage Prices', 'class' => 'active'));
					}
					else
					{
						echo anchor('admin/pricing', 'Pricing', array('title' => 'Manage Prices')); 
					}		
				?>
			</li>  
		</ul> 
	</nav> 
</aside>