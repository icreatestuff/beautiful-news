<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Booking extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 */
	public function index()
	{	
		$this->booking_index_form();
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('booking/index');
		}
		else
		{
			// Form validates so process booking and move on to extras page
			foreach ($_POST as $key => $val)
			{
				$data[$key] = $this->input->post($key);
			}
			
			// Add payment status and calculate end_date from start_date + duration
			$data['payment_status'] = "Unpaid";
			
			$start_date_ts = strtotime($data['start_date']);
			$data['start_date'] = date('Y-m-d H:i:s', $start_date_ts);
			
			$end_date_ts = $start_date_ts + (60 * 60 * 24 * $data['duration']);
			$data['end_date'] = date('Y-m-d H:i:s', $end_date_ts);
			
			// Generate Booking Reference number FORMAT: ddmmyy_UNITID_#GUESTS
			// We need the unit Code for this accommodation
			$this->load->model('accommodation_model');
			$unit_query = $this->accommodation_model->get_unit_code($data['accommodation_ids']);
			$unit_row = $unit_query->row();
			
			$data['booking_ref'] = date('dmY', $start_date_ts) . "_" . $unit_row->unit_id . "_" . $data['total_guests'];
		
			// Unset unused elements
			unset($data['submit']);	
			unset($data['duration']);
			
			// Create Booking record
			$this->load->model('booking_model');
			$this->booking_model->insert_booking_row($data);
			
			// Create Calendar record
			// Get last insert ID from bookings table
			$data['booking_id'] = $this->db->insert_id();
			
			$key_booking_data = array(
				'booking_id' => $data['booking_id'],
				'booking_ref' => $data['booking_ref']
			);
			
			// Unset any fields we don't need for calendar table
			unset($data['total_guests']);
			unset($data['total_price']);
			unset($data['payment_status']);
			unset($data['total_guests']);
			unset($data['booking_ref']);
			
			$data['accommodation_id'] = $data['accommodation_ids'];
			unset($data['accommodation_ids']);
			
			$this->booking_model->insert_calendar_row($data);
			
			$this->load->library('session');
			$this->session->set_userdata('booking_id', $key_booking_data['booking_id']);
			
			redirect('booking/extras/' . $key_booking_data['booking_id']);
		}
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Extras choice page.
	 *
	 */
	public function extras()
	{
		if ($this->uri->segment(3) === FALSE || !is_numeric($this->uri->segment(3)))
		{
			redirect('accommodation/index');
		}
		else
		{
			// Check if session data booking_id equals segment 3
			$booking_id = $this->uri->segment(3);
			
			if ($this->session->userdata('booking_id') != $booking_id)
			{
				redirect('accommodation/index');
			}
			else
			{				
				//Manage Contact Page
				$this->extras_form();

				if ($this->form_validation->run() == FALSE)
				{	
					$data = array();
					$data['booking_id'] = $booking_id;
				
					// Get site_id from booking data
					$this->load->model('booking_model');
					$booking_query = $this->booking_model->get_booking($booking_id);
					$booking_row = $booking_query->row();
					
					$data['total_price'] = $booking_row->total_price;
					
					// Get all extra types	
					$extra_types_query = $this->booking_model->get_extra_types();
					
					if ($extra_types_query->num_rows() > 0)
					{
						foreach ($extra_types_query->result() as $extra_type)
						{
							// Get all extras with that type assigned
							$extras_query = $this->booking_model->get_extras($extra_type->id, $booking_row->site_id);
							
							if ($extras_query->num_rows() > 0)
							{
								// Create Extra Types -> Extras array items
								$data['extra_types'][] = array(
									'id'		=> $extra_type->id,
									'name'		=> $extra_type->name,
									'extras'	=> $extras_query
								);
							}
						}
					}					
					
					$this->load->view('booking/extras', $data);
				}
				else
				{
					// Extras form validates! Update booking total price and put extras in purchased table
					// Process Extras form results
					// Coming from form booking_id, submit, extra_price_x, extra_quantity_x, extra_nights_x
					foreach ($_POST as $key => $val)
					{
						$data[$key] = $this->input->post($key);
					}
					
					unset($data['submit']);	
					
					// Update booking total_price
					$this->load->model('booking_model');
					$this->booking_model->update_total_price($data['booking_id'], $data['total_price']);
					
					$insert_data = array();
					
					// Get extras from $data where quantity is 1 or more and add them to insert_data
					foreach ($data as $key => $val)
					{
						if (substr($key, 0, 15) === "extra_quantity_")
						{
							if ($val > 0)
							{
								$extra_id = substr($key, 15);
								
								// Set nights
								if (isset($data['extra_nights_' . $extra_id]))
								{
									$nights = $data['extra_nights_' . $extra_id];
								}
								else
								{
									$nights = 0;
								}
								
								// Calculate price
								if ($nights === 0)
								{
									$price = round($val * $data['extra_price_' . $extra_id], 2);
								}
								else
								{
									$price = round($val * $data['extra_nights_' . $extra_id] * $data['extra_price_' . $extra_id], 2);
								}
							
								$insert_data[] = array(
									'extra_id' 		=> $extra_id,
									'booking_id'	=> $data['booking_id'],
									'quantity'		=> $val,
									'nights'		=> $nights,
									'price'			=> $price
								);
							}
						}
					}
					
					// Only try to insert if there is some data!
					if (isset($insert_data) && !empty($insert_data))
					{
						$this->booking_model->insert_extra_purchases($insert_data);
					}
					
					redirect('booking/contact/' . $data['booking_id']);
				}
			}
		}		
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Add/Edit Extras choice page.
	 *
	 */
	public function edit_extras()
	{
		if ($this->uri->segment(3) === FALSE || !is_numeric($this->uri->segment(3)))
		{
			redirect('accommodation/index');
		}
		else
		{
			// Check if session data booking_id equals segment 3
			$booking_id = $this->uri->segment(3);
			
			if ($this->session->userdata('booking_id') != $booking_id)
			{
				redirect('accommodation/index');
			}
			else
			{				
				//Manage Extras Page
				$this->extras_form();

				if ($this->form_validation->run() == FALSE)
				{	
					$data = array();
					$data['booking_id'] = $booking_id;
				
					// Get site_id from booking data
					$this->load->model('booking_model');
					$booking_query = $this->booking_model->get_booking($booking_id);
					$booking_row = $booking_query->row();
					
					$data['total_price'] = $booking_row->total_price;
					
					// Get all extra types	
					$extra_types_query = $this->booking_model->get_extra_types();
					
					if ($extra_types_query->num_rows() > 0)
					{
						foreach ($extra_types_query->result() as $extra_type)
						{
							// Get all extras with that type assigned
							$extras_query = $this->booking_model->get_extras($extra_type->id, $booking_row->site_id);
							
							if ($extras_query->num_rows() > 0)
							{
								// Create Extra Types -> Extras array items
								$data['extra_types'][] = array(
									'id'		=> $extra_type->id,
									'name'		=> $extra_type->name,
									'extras'	=> $extras_query
								);
							}
						}
					}	
					
					// Get extras already selected
					$data['selected_extras'] = $this->booking_model->get_booked_extras($booking_id);
					
					// Calculate price of extras already selected
					$data['extras_price'] = 0;
					
					if ($data['selected_extras']->num_rows() > 0)
					{
						foreach ($data['selected_extras']->result() as $sExtra)
						{
							$data['extras_price'] = $data['extras_price'] + intval($sExtra->price);
						}
					}	

					$this->load->view('booking/edit_extras', $data);
				}
				else
				{
					// Extras form validates! Update booking total price and put extras in purchased table
					// Process Extras form results
					// Coming from form booking_id, submit, extra_price_x, extra_quantity_x, extra_nights_x
					foreach ($_POST as $key => $val)
					{
						$data[$key] = $this->input->post($key);
					}
					
					unset($data['submit']);	
				
					// First of all lets delete all references to this booking in the purchased_extras table,
					// then just write all the new/amended extras to it.
					$this->load->model('booking_model');
					
					$this->booking_model->delete_purchased_extras($data['booking_id']);
					
					// Update booking total_price
					$this->booking_model->update_total_price($data['booking_id'], $data['total_price']);
					
					// Get extras from $data where quantity is 1 or more and add them to insert_data
					foreach ($data as $key => $val)
					{
						if (substr($key, 0, 15) === "extra_quantity_")
						{
							if ($val > 0)
							{
								$extra_id = substr($key, 15);
								
								// Set nights
								if (isset($data['extra_nights_' . $extra_id]))
								{
									$nights = $data['extra_nights_' . $extra_id];
								}
								else
								{
									$nights = 0;
								}
								
								// Calculate price
								if ($nights === 0)
								{
									$price = round($val * $data['extra_price_' . $extra_id], 2);
								}
								else
								{
									$price = round($val * $data['extra_nights_' . $extra_id] * $data['extra_price_' . $extra_id], 2);
								}
							
								$insert_data[] = array(
									'extra_id' 		=> $extra_id,
									'booking_id'	=> $data['booking_id'],
									'quantity'		=> $val,
									'nights'		=> $nights,
									'price'			=> $price
								);
							}
						}
					}
					
					// Only try to insert if there is some data!
					if (isset($insert_data) && !empty($insert_data))
					{
						$this->booking_model->insert_extra_purchases($insert_data);
					}
					
					redirect('booking/overview/' . $data['booking_id']);
				}
			}
		}		
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Booking Contact insert form.
	 *
	 */
	public function contact()
	{
		if ($this->uri->segment(3) === FALSE || !is_numeric($this->uri->segment(3)))
		{
			echo $this->uri->segment(3) .",". gettype($this->uri->segment(3));
			
			redirect('accommodation/index');
		}
		else
		{
			// Check if session data booking_id equals segment 3
			$booking_id = $this->uri->segment(3);
			
			if ($this->session->userdata('booking_id') != $booking_id)
			{
				redirect('accommodation/index');
			}
			else
			{
				$data['booking_id'] = $booking_id;
				
				// If user is logged in already then lets use their existing
				// contact details rather than have them fill out the form
				// all over again.
				$user_id = $this->session->userdata('user_id');
				if (isset($user_id) && !empty($user_id) && $user_id !== 0)
				{
					$is_logged_in = $this->session->userdata('is_logged_in');
					if (isset($is_logged_in) OR $is_logged_in === TRUE)
					{	
					
						// Update booking with contact_id of logged in member
						$this->load->model('member_model');
						
						// Get contact_id
						$contact = $this->member_model->get_member_info($this->session->userdata('user_id'));
						
						if ($contact->num_rows() == 1)
						{
							$contact_row = $contact->row();
							
							$this->member_model->update_booking(array('contact_id' => $contact_row->id), $data['booking_id']);	
							
							// Update booking_ref with last_name
							$this->load->model('booking_model');
							$booking_query = $this->booking_model->get_booking($data['booking_id']);
							
							if ($booking_query->num_rows() == 1)
							{
								$booking = $booking_query->row();
								$new_booking_ref = array('booking_ref' => $booking->booking_ref . "_" . strtoupper($contact_row->last_name));
	
								$this->booking_model->update_booking($data['booking_id'], $new_booking_ref);
							}
							
							// Proceed to booking overview page!
							redirect('booking/overview/' . $data['booking_id']);
						}
					}
				}
				else
				{
					//Manage Contact Page
					$this->contact_form();
	
					if ($this->form_validation->run() == FALSE)
					{	
						$this->load->view('booking/contact', $data);
					}
					else
					{
						// Form validates! Do stuff with the data.
						foreach ($_POST as $key => $val)
						{
							$contact_data[$key] = $this->input->post($key);
						}
						
						// Subscribe user to Mailchimp list if newsletter_registration is 'y'
						if (isset($contact_data['newsletter_registration']) && $contact_data['newsletter_registration'] === 'y') 
						{
							$this->mailchimp_list_subscribe($contact_data['email_address'], $contact_data['first_name'], $contact_data['last_name']);
						}
						
						// Create a member account using email_address, first_name, last_name, password
						
						$this->load->library('password_hash', array(10, FALSE));
						$this->load->model('member_model');
						
						$member_data = array(
							'username' 			=> $contact_data['email_address'],
							'screen_name' 		=> $contact_data['first_name'] . " " . $contact_data['last_name'],
							'password' 			=> $this->password_hash->HashPassword($contact_data['password']),
							'email_address'		=> $contact_data['email_address'],
							"admin_access"		=> "n"
						);
						
						$this->member_model->register($member_data);
						
						$contact_data['member_id'] = $this->db->insert_id();
						
						// Log user in straight away by setting session variables.
						$session_data = array(
							'screen_name' 	=> $member_data['screen_name'],
							'is_logged_in' 	=> true,
							'is_admin'		=> "n",
							'site_id' 		=> $this->session->userdata('site_id'),
							'user_id'		=> $contact_data['member_id']
						);
					
						$this->session->set_userdata($session_data);
						
						// Remove unused variables
						unset($contact_data['submit']);
						unset($contact_data['booking_id']);
						unset($contact_data['terms_and_conditions']);
						unset($contact_data['newsletter_registration']);
						unset($contact_data['password']);
						unset($contact_data['password_confirmation']);
						
						// Insert contact into db
						$this->load->model('booking_model');
						$this->booking_model->insert_contact_row($contact_data);
	
						$contact_id = $this->db->insert_id();
						
						// Update booking record with new contact ID
						$this->booking_model->add_booking_contact($data['booking_id'], $contact_id);
						
						// Update booking_ref with last_name
						$booking_query = $this->booking_model->get_booking($data['booking_id']);
						
						if ($booking_query->num_rows() == 1)
						{
							$booking = $booking_query->row();
							$new_booking_ref = array('booking_ref' => $booking->booking_ref . "_" . strtoupper($contact_data['last_name']));

							$this->booking_model->update_booking($data['booking_id'], $new_booking_ref);
						}
						
						// Proceed to booking overview page!
						redirect('booking/overview/' . $data['booking_id']);
					}
				}
			}	
		}
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Booking Overview/Review Page.
	 *
	 */
	public function overview()
	{
		if ($this->uri->segment(3) === FALSE || !is_numeric($this->uri->segment(3)))
		{
			redirect('accommodation/index');
		}
		else
		{
			// Check if session data booking_id equals segment 3
			$booking_id = $this->uri->segment(3);
			
			if ($this->session->userdata('booking_id') != $booking_id)
			{
				redirect('accommodation/index');
			}
			else
			{
				//Get Booking Details
				$this->load->model('booking_model');
				$data['booking_details'] = $this->booking_model->get_booking($booking_id);
				
				if ($data['booking_details']->num_rows() > 0)
				{
					$booking = $data['booking_details']->row();
					$accommodation_id = $booking->accommodation_ids;
					$contact_id = $booking->contact_id;
				}
				
				// Get Accommodation Details
				$data['accommodation_details'] = $this->booking_model->get_accommodation($accommodation_id);
				
				// Get Contact Details
				$data['contact_details'] = $this->booking_model->get_contact($contact_id);
				
				// Get Extras
				$data['extras'] = $this->booking_model->get_booked_extras($booking_id);
				
				// User Details
				$data['user'] = array(
					'screen_name' 	=> $this->session->userdata('screen_name'),
					'user_id'		=> $this->session->userdata('user_id')
				);
			
				$this->load->view('booking/overview', $data);
			}
		}
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get available accommodation from start_date and duration
	 *
	 */
	public function get_available_accommodation()
	{
		$post_start_date = $this->input->post('start_date');
		$post_duration = $this->input->post('duration');
		
		// Format dates
		$start_date_ts = strtotime($post_start_date);
		$start_date = date('Y-m-d', $start_date_ts);
		
		$end_date_ts = $start_date_ts + (60 * 60 * 24 * $post_duration);
		$end_date = date('Y-m-d', $end_date_ts);
		
		// Get all calendar entries whose start_date is between chosen start dates and end date
		$this->load->model('booking_model');
		$calendar_query = $this->booking_model->get_calendar_entries_between_dates($start_date, $end_date);
		
		// Get all accommodation
		$accommodation_query = $this->booking_model->get_all_accommodation(); // May need to modify this for a specific site in future
	
		$accommodation_list = "";
	
		if ($calendar_query->num_rows() > 0)
		{
			$all_accommodation = $accommodation_query->result_array();
		
			foreach($calendar_query->result() as $calendar)
			{
				$accommodation_id = $calendar->accommodation_id;
				
				// Check if id is in all accommodation array
				foreach ($all_accommodation as $key => $item)
				{
					if ($item['id'] === $accommodation_id)
					{
						unset($all_accommodation[$key]);
					}
				}
			}
			
			// Now all accommodation filtered out that isn't available, create list
			if (count($all_accommodation) > 0)
			{
				foreach ($all_accommodation as $accommodation)
				{
					// Calculate price for this accommodation for this timeframe
					$ppn = $this->get_price_per_night($accommodation['id'], $start_date);
					
					$price = ($ppn * $post_duration) + ($accommodation['additional_per_night_charge'] * $post_duration);
				
					$accommodation_list .= "<li data-price='" . $price . "' data-sleeps='" . $accommodation['sleeps'] . "'><h2>" . $accommodation['name'] . " &mdash; This would cost &pound;" . $price . " for " . $post_duration . " nights</h2><div class='accommodation-info'><img src='" . base_url() . "images/accommodation/" . $accommodation['photo_1'] . "' width='140' alt='" . $accommodation['name'] . " main photo' /><a href='" . base_url() . "index.php/accommodation/unit/" . $accommodation['id'] . "' title='View full accommodation detail'>Read more about this accommodation</a><input type='radio' name='accommodation_ids' value='" . $accommodation['id'] . "' /></div></li>";
				}
			}
		}
		else
		{
			// No bookings made in that timeframe so return all accommodation
			if ($accommodation_query->num_rows() > 0)
			{
				foreach ($accommodation_query->result() as $accommodation)
				{
					// Calculate price for this accommodation for this timeframe
					$ppn = $this->get_price_per_night($accommodation->id, $start_date);
					
					$price = ($ppn * $post_duration) + ($accommodation->additional_per_night_charge * $post_duration);
				
					$accommodation_list .= "<li data-price='" . $price . "' data-sleeps='" . $accommodation->sleeps . "'><h2>" . $accommodation->name . " &mdash; This would cost &pound;" . $price . " for " . $post_duration . " nights</h2><div class='accommodation-info'><img src='" . base_url() . "images/accommodation/" . $accommodation->photo_1 . "' width='140' alt='" . $accommodation->name . " main photo' /><a href='" . base_url() . "index.php/accommodation/unit/" . $accommodation->id . "' title='View full accommodation detail'>Read more about this accommodation</a><input type='radio' name='accommodation_ids' value='" . $accommodation->id . "' /></div></li>";
				}
			}
		}

		echo json_encode($accommodation_list);
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Booking Index Form.
	 *
	 */
	function booking_index_form()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('site_id', 'Site ID', 'trim|numeric');
		$this->form_validation->set_rules('accommodation_ids', 'Accommodation', 'trim|numeric');
		$this->form_validation->set_rules('start_date', 'Arrival Date', 'trim|required');
		$this->form_validation->set_rules('duration', 'Number of nights', 'trim|numeric|required');
		$this->form_validation->set_rules('total_guests', 'Total Guests', 'trim|numeric|required');
		$this->form_validation->set_rules('total_price', 'Total Price', 'trim|numeric');
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Extras Form.
	 *
	 */
	function extras_form()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('total_price', 'Total Price', 'trim|required');
		$this->form_validation->set_rules('booking_id', 'Booking', 'trim|required');
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Contact Form.
	 *
	 */
	function contact_form()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('title', 'Title', 'trim|required');
		$this->form_validation->set_rules('first_name', 'First name', 'trim|required|min_length[2]');
		$this->form_validation->set_rules('last_name', 'Surname', 'trim|required|min_length[2]');
		$this->form_validation->set_rules('birth_day', 'Birth Day', 'trim|numeric|required');
		$this->form_validation->set_rules('birth_month', 'Birth Month', 'trim|numeric|required');
		$this->form_validation->set_rules('birth_year', 'Birth Year', 'trim|numeric|required');
		$this->form_validation->set_rules('house_name', 'House name/number', 'trim|required');
		$this->form_validation->set_rules('address_line_1', 'Address Line 1', 'trim|required|min_length[2]');
		$this->form_validation->set_rules('address_line_2', 'Address Line 2', 'trim');
		$this->form_validation->set_rules('city', 'Town/City', 'trim|required|min_length[2]');
		$this->form_validation->set_rules('county', 'County', 'trim|required|min_length[2]');
		$this->form_validation->set_rules('post_code', 'Postcode', 'trim|required|min_length[6]');
		$this->form_validation->set_rules('daytime_number', 'Daytime Contact Number', 'trim|required|min_length[9]');
		$this->form_validation->set_rules('mobile_number', 'Mobile Contact Number', 'trim|numeric');
		$this->form_validation->set_rules('email_address', 'Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('terms_and_conditions', 'Terms and Conditions', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
		$this->form_validation->set_rules('password_confirmation', 'Password Confirmation', 'trim|required|matches[password]');
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get Base Price for Start Date
	 *
	 */
	function get_price_per_night($accommodation_id, $selected_date)
	{
		$this->load->model('booking_model');
		
		$price_query = $this->booking_model->get_base_price($accommodation_id);
		if ($price_query->num_rows() > 0)
		{
			$price_row = $price_query->row();
			$price = $price_row->base_price;
			$type = $price_row->name;
		}
		
		$query = $this->booking_model->get_price();
		
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				// Check if given date is between row start and end dates
				$in_range = $this->check_in_range($row->start_date, $row->end_date, $selected_date);
				
				if ($in_range)
				{	
					$type = strtolower(str_replace(" ", "_", $type));
					$percentage_increase = $row->$type; 
										
					$price = round(($price / 100) * (100 + $percentage_increase));
					
					// Round to nearest 5
					$price = round($price / 5) * 5;
				}
			}
		}
		
		return $price;
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Check if given date is in range
	 *
	 */
	function check_in_range($start_date, $end_date, $date_from_user)
	{
		// Convert to timestamp
		$start_ts = strtotime($start_date);
		$end_ts = strtotime($end_date);
		$user_ts = strtotime($date_from_user);
		
		// Check that user date is between start & end
		return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
	}
	
	
	// --------------------------------------------------------------------------------------------------------------
	/**
	 * Mailchimp List Subscribe.
	 *
	 */
	function mailchimp_list_subscribe($email_address, $first_name, $last_name)
    {
    	require_once '/Applications/MAMP/htdocs/bivouac/application/third_party/mailchimp-api-class/examples/inc/MCAPI.class.php';
		require_once '/Applications/MAMP/htdocs/bivouac/application/third_party/mailchimp-api-class/examples/inc/config.inc.php';
		
		$api = new MCAPI($apikey);
		
		$merge_vars = array(
			'FNAME' => $first_name, 
			'LNAME' => $last_name
		);
		
		$retval = $api->listSubscribe($listId, $email_address, $merge_vars);
		
		if ($api->errorCode)
		{
			return false;
		} 
		
		return true;
    }	
}

/* End of file booking.php */
/* Location: ./application/controllers/booking.php */