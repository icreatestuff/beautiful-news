<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Accommodation extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		// Site Id session variable
		$this->load->library('session');
		$site_id = $this->session->userdata('site_id');
		
		if (!isset($site_id) || empty($site_id))
		{
			$site_id = 1;
			$this->session->set_userdata('site_id', $site_id);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Index Page for this controller.
	 *
	 */
	public function index()
	{
		$site_id = $this->session->userdata('site_id');
		
		$this->load->model('accommodation_model');
		$data['query'] = $this->accommodation_model->get_all_for_site($site_id);
		
		$this->load->view('accommodation/index', $data);
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Single entry accommodation page
	 *
	 */
	public function unit()
	{
		if ($this->uri->segment(3) === FALSE)
		{
			redirect('/accommodation/index');
		}
		else
		{
			$this->load->model('accommodation_model');
			$this->accommodation_booking_form();
			$accommodation_id = $this->uri->segment(3);
			
			if ($this->form_validation->run() == FALSE)
			{	
				$accommodation_row = $this->accommodation_model->get_single_row($accommodation_id);
				$data['accommodation'] = $accommodation_row->row();
			
				$this->load->view('accommodation/unit', $data);
			}
			else
			{
				// Booking Form validates so create new booking.
				foreach ($_POST as $key => $val)
				{
					$data[$key] = $this->input->post($key);
				}
				
				// Add payment status and calculate end_date from start_date + duration
				$data['payment_status'] = "Unpaid";
				
				$start_date_ts = strtotime($data['start_date']);
				$end_date_ts = $start_date_ts + (60 * 60 * 24 * $data['duration']);
				$data['start_date'] = date('Y-m-d H:i:s', $start_date_ts);
				$data['end_date'] = date('Y-m-d H:i:s', $end_date_ts);
				
				// Generate Booking Reference number FORMAT: ddmmyy_UNITID_#GUESTS
				// We need the unit Code for this accommodation
				$unit_query = $this->accommodation_model->get_unit_code($accommodation_id);
				$unit_row = $unit_query->row();
				
				$data['booking_ref'] = date('dmY', $start_date_ts) . "_" . $unit_row->unit_id . "_" . $data['total_guests'];
			
				// Unset unused elements
				unset($data['submit']);	
				unset($data['duration']);
				
				// Create Booking record
				$this->load->model('booking_model');
				$this->booking_model->insert_booking_row($data);
				
				// Create Calendar record
				// Get last insert ID from bookings table
				$data['booking_id'] = $this->db->insert_id();
				
				$key_booking_data = array(
					'booking_id' => $data['booking_id'],
					'booking_ref' => $data['booking_ref']
				);
				
				// Unset any fields we don't need for calendar table
				unset($data['total_guests']);
				unset($data['total_price']);
				unset($data['payment_status']);
				unset($data['total_guests']);
				unset($data['booking_ref']);
				
				$data['accommodation_id'] = $data['accommodation_ids'];
				unset($data['accommodation_ids']);
				
				$this->booking_model->insert_calendar_row($data);
				
				$this->load->library('session');
				$this->session->set_userdata('booking_id', $key_booking_data['booking_id']);
				
				redirect('booking/extras/' . $key_booking_data['booking_id']);
			}
		}
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get booked dates to make unavailable on calendar
	 *
	 */
	public function get_booked_dates()
	{
		$data = array('response' => false);
		
		$accommodation_id = $this->input->post('id');
		$is_bunk_barn = $this->input->post('bunk_barn');
		
		$this->load->model('booking_model');
		
		$accommodation_beds_query = $this->booking_model->get_total_beds($accommodation_id);
		$accommodation_row = $accommodation_beds_query->row();
		$data['beds'] = $accommodation_row->sleeps;
		
		$query = $this->booking_model->get_all_from_accommodation_id($accommodation_id);
		
		if ($query->num_rows() > 0)
		{
			$data['response'] = true;
			
			$bed_date_data = array();
						
			foreach ($query->result() as $row)
			{
				// Get dates between start and end date, formatted as dd/mm/yy
				$start_date_ts = strtotime($row->start_date);
				$start_date = date('d-m-Y', $start_date_ts);
				
				// The end_date is actually a new booking in day so we need to make it -1 day
				$end_date_ts = strtotime($row->end_date) - (60 * 60 * 24);
				$end_date = date('d-m-Y', $end_date_ts);
				
				$current_date = $start_date_ts;
				
				while ($current_date <= $end_date_ts)
				{  
				    $total_beds = $accommodation_row->sleeps;
				  
				  	if ($is_bunk_barn)
					{
						$bed_date_data = $this->guests_per_day($accommodation_id, $current_date, $bed_date_data, $total_beds);
						
						// Add this new day to the dates array  
						$data['dates'][] = array(date('d-m-Y', $current_date), $bed_date_data[$current_date]);
					}
					else
					{
						// Add this new day to the dates array  
						$data['dates'][] = array(date('d-m-Y', $current_date), $total_beds);
					}
					
					// Add a day to the current date  
			    	$current_date = $current_date + (60 * 60 * 24); 
				}  
			}
		}
		//print_r($bed_date_data);
	
		echo json_encode($data);
	}	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get available durations & prices based on selected start_date
	 *
	 */
	public function get_durations()
	{
		$accommodation_id = $this->input->post('id');
		$start_date = $this->input->post('start_date');
		
		// Get accommodation price per night (ppn)
		$ppn = $this->get_price_per_night($accommodation_id, $start_date);
		
		$additional_cost = $this->get_additional_accommodation_cost($accommodation_id);
	
		// Get all bookings up to 2 weeks after this start_date
		$start_date_ts = strtotime($start_date);
		$start_date = date('Y-m-d', $start_date_ts);
		$selected_start_date = date('D jS M', strtotime($start_date));
		$day = date('l', $start_date_ts);
		$two_weeks_ahead = date('Y-m-d', $start_date_ts + (60 * 60 * 24 * 14));
		
		$duration = "";
		
		$this->load->model('booking_model');
		
		// Get all public holidays
		$public_holidays = $this->public_holidays();
		
		$query = $this->booking_model->get_bookings_within_two_weeks($accommodation_id, $start_date, $two_weeks_ahead);
		
		if ($query->num_rows() > 0)
		{
			$row = $query->row();
			$start = $row->start_date;	
			$diff = $this->date_difference($start_date, $start);
			$holiday_in_range = false;
			$selected_start = date('Y-m-d', $start_date_ts);
			$calculated_end_date = date('D jS M', strtotime($start));
			
			// Array = (nights, price, start_date, end_date)
			$duration = array();
			
			if ($diff < 7)
			{
				$duration[] = array($diff, ($diff * $ppn) + ($diff * $additional_cost), $selected_start_date, $calculated_end_date);
			} 
			else if ($diff >= 7)
			{
				if ($day === 'Monday')
				{
					$duration[] = array(4, (4 * $ppn) + (4 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
				else
				{
					$duration[] = array(3, (3 * $ppn) + (3 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
			}

			if ($diff == 6)
			{
				$duration[] = array(6, (6 * $ppn) + (6 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			else if ($diff == 7)
			{				
				$duration[] = array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			else if ($diff == 10)
			{		
				if ($day === 'Monday')
				{		
					$duration[] = array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
				else
				{
					$duration[] = array(6, (6 * $ppn) + (6 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
				
				$duration[] = array(10, (10 * $ppn) + (10 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			else if ($diff == 11)
			{
				$duration[] = array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, $calculated_end_date);
				$duration[] = array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			else if ($diff == 13)
			{
				$duration[] = array(6, (6 * $ppn) + (6 * $additional_cost), $selected_start_date, $calculated_end_date);
				$duration[] = array(13, (13 * $ppn) + (13 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			else if ($diff == 14)
			{
				$duration[] = array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, $calculated_end_date);
				
				if ($day === 'Monday')
				{
					$duration[] = array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
				else
				{
					$duration[] = array(10, (10 * $ppn) + (10 * $additional_cost), $selected_start_date, $calculated_end_date);
				}
				
				$duration[] = array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, $calculated_end_date);
			}
			
		}
		else
		{
			// No bookings exist up to 2 weeks ahead
			// Is start_date a Monday or Friday?
			$one_day = 60 * 60 * 24;
			$holiday_in_range = false;
			$selected_start = date('Y-m-d', $start_date_ts);
			$duration = array();
			
			// Loop through all holiday start_dates to see if any are within $selected start and end dates
			foreach ($public_holidays as $holiday)
			{
				if ($holiday_in_range)
				{
					break;
				}
				
				// Is holiday date a monday?
				if (date('l', strtotime($holiday['start_date'])) === "Monday")
				{
					$holiday_in_range = $this->check_in_range($selected_start, $two_weeks_ahead, $holiday['start_date']);
					$holiday_date = $holiday['start_date'];
				}
			}
			
			if ($day === 'Monday')
			{
				if ($holiday_in_range)
				{
					$diff = $this->date_difference($selected_start, $holiday_date);
					if ($diff == 7)
					{
						$duration = array(
							array(4, (4 * $ppn) + (4 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (4 * $one_day))),
							array(8, (8 * $ppn) + (8 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (8 * $one_day))),
							array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (11 * $one_day))),
							array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (14 * $one_day)))
						);
					} 
					else
					{
						$duration = array(
							array(4, (4 * $ppn) + (4 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (4 * $one_day))),
							array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (7 * $one_day))),
							array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (11 * $one_day))),
							array(15, (15 * $ppn) + (15 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (15 * $one_day)))
						);
					}
				}
				else
				{
					$duration = array(
						array(4, (4 * $ppn) + (4 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (4 * $one_day))),
						array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (7 * $one_day))),
						array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (11 * $one_day))),
						array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (14 * $one_day)))
					);
				}
			}
			else if ($day === "Tuesday")
			{
				$duration = array(
					array(3, (3 * $ppn) + (3 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (3 * $one_day))),
					array(6, (6 * $ppn) + (6 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (6 * $one_day))),
					array(10, (10 * $ppn) + (10 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (10 * $one_day))),
					array(13, (13 * $ppn) + (13 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (13 * $one_day)))
				);
			}
			else
			{
				if ($holiday_in_range)
				{
					$diff = $this->date_difference($selected_start, $holiday_date);					
					
					if ($diff == 3)
					{
						$duration = array(
							array(4, (4 * $ppn) + (4 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (4 * $one_day))),
							array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (7 * $one_day))),
							array(10, (10 * $ppn) + (10 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (10 * $one_day))),
							array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (14 * $one_day)))
						);
					}
					else
					{
						$duration = array(
							array(3, (3 * $ppn) + (3 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (3 * $one_day))),
							array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (7 * $one_day))),
							array(11, (11 * $ppn) + (11 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (11 * $one_day))),
							array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (14 * $one_day)))
						);
					}
				}
				else
				{
					$duration = array(
						array(3, (3 * $ppn) + (3 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (3 * $one_day))),
						array(7, (7 * $ppn) + (7 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (7 * $one_day))),
						array(10, (10 * $ppn) + (10 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (10 * $one_day))),
						array(14, (14 * $ppn) + (14 * $additional_cost), $selected_start_date, date('D jS M', $start_date_ts + (14 * $one_day)))
					);
				}
			}	
		}
		
		$data['durations'] = $duration; 
		
		echo json_encode($data);
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get available durations & prices based on selected start_date for bunk barns
	 *
	 */
	public function get_bunk_barn_durations()
	{
		$accommodation_id = $this->input->post('id');
		$start_date = $this->input->post('start_date');
		
		// Get accommodation price per night (ppn)
		$ppn = $this->get_price_per_night($accommodation_id, $start_date);
	
		// Get all bookings up to 2 weeks after this start_date
		$start_date_ts = strtotime($start_date);
		$start_date = date('Y-m-d', $start_date_ts);
		$selected_start_date = date('D jS M', $start_date_ts);
		$day = date('l', $start_date_ts);
		$one_day = 60 * 60 * 24;
		
		$two_weeks_ahead = date('Y-m-d', $start_date_ts + (60 * 60 * 24 * 14));
		
		$duration = "";
		$bed_date_data = array();
		
		$this->load->model('booking_model');
		$accommodation_beds_query = $this->booking_model->get_total_beds($accommodation_id);
		$accommodation_row = $accommodation_beds_query->row();
		
		$query = $this->booking_model->get_bookings_within_two_weeks($accommodation_id, $start_date, $two_weeks_ahead);
		
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				$existing_start_date_ts = strtotime($row->start_date);
				$existing_end_date_ts = strtotime($row->end_date);
				$current_date = $existing_start_date_ts;
				
				while ($current_date <= $existing_end_date_ts)
				{  
			    	$total_beds = $accommodation_row->sleeps;
			  
					$bed_date_data = $this->guests_per_day($accommodation_id, $current_date, $bed_date_data, $total_beds);
					
					// Add a day to the current date  
			    	$current_date = $current_date + (60 * 60 * 24);   
				}
			}	
		}
		
		// Array = (nights, price, start_date, end_date)
		$duration = array();
		
		// Calculate difference in days between selected start date and closest date in $bed_date_data
		// that has 0 beds remaining.
		if (in_array(0, $bed_date_data))
		{
			// Sort array so closest date is first.
			ksort($bed_date_data);
			
			$closest_date_ts = array_search(0, $bed_date_data);
			
			$diff = $this->date_difference($start_date, date('d-m-Y', $closest_date_ts));
			$calculated_end_date = date('D jS M', $closest_date_ts);
			
			// Add duration option to array for every night up to difference calculated
			for ($i = 1; $i <= $diff; $i++)
			{
				$duration[] = array($i, $i * $ppn, $selected_start_date, date('D jS M', $start_date_ts + ($i * $one_day)));
			}
		}
		else
		{
			// Add up to 2 weeks worth of dates to duration array
			for ($i = 1; $i <= 14; $i++)
			{
				$duration[] = array($i, $i * $ppn, $selected_start_date, date('D jS M', $start_date_ts + ($i * $one_day)));
			}
		}
		
		$data['durations'] = $duration;
		
		echo json_encode($data);
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get Accommodation guests on a given date. Return array of remaining beds for dates
	 *
	 */
	private function guests_per_day($accommodation_id, $current_date, $bed_date_data, $total_beds)
	{
		$bookings_query = $this->booking_model->get_guests();
		
		if ($bookings_query->num_rows() > 0)
		{	
			foreach ($bookings_query->result() as $bookings_row)
			{	
				$process = false;
				$ids = $bookings_row->accommodation_ids;
				$ids = explode("|", $ids);
				
				if (is_array($ids))
				{
					
					if (in_array($accommodation_id, $ids))
					{	
						$process = true;
					}

				}
				else
				{
					if ($accommodation_id === $ids)
					{
						$process = true;
					}
				}
				
				if ($process)
				{													
					$booking_start_date = date('d-m-Y', strtotime($bookings_row->start_date));				
					$booking_end_date = date('d-m-Y', strtotime($bookings_row->end_date));
					
					if ($this->check_in_range($booking_start_date, $booking_end_date, date('d-m-Y', $current_date)))
					{
						if (array_key_exists($current_date, $bed_date_data))
						{
							$bed_date_data[$current_date] = $bed_date_data[$current_date] - $bookings_row->total_guests;
						}
						else
						{
							$total_beds = $total_beds - $bookings_row->total_guests;
							$bed_date_data[$current_date] = $total_beds;
						}
					}
				}
			}
		}
		
		return $bed_date_data;
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get Base Price for Start Date
	 *
	 */
	function get_price_per_night($accommodation_id, $selected_date)
	{
		$this->load->model('booking_model');
		
		$price_query = $this->booking_model->get_base_price($accommodation_id);
		if ($price_query->num_rows() > 0)
		{
			$price_row = $price_query->row();
			$price = $price_row->base_price;
			$type = $price_row->name;
		}
		
		$query = $this->booking_model->get_price();
		
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				// Check if given date is between row start and end dates
				$in_range = $this->check_in_range($row->start_date, $row->end_date, $selected_date);
				
				if ($in_range)
				{	
					$type = strtolower(str_replace(" ", "_", $type));
					$percentage_increase = $row->$type; 
										
					$price = round(($price / 100) * (100 + $percentage_increase));
					
					// Round to nearest 5
					$price = round($price / 5) * 5;
				}
			}
		}
		
		return $price;
	}
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get Additional price for accommodation
	 *
	 */
	function get_additional_accommodation_cost($accommodation_id)
	{
		$this->load->model('booking_model');
		
		$cost_query = $this->booking_model->get_additional_cost($accommodation_id);
		if ($cost_query->num_rows() > 0)
		{
			$cost_row = $cost_query->row();
			$cost = $cost_row->additional_per_night_charge;
		}
		
		return $cost;
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get all public holidays from db. Return array of start and end dates
	 *
	 */
	function get_public_holidays()
	{
		echo json_encode($this->public_holidays());
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get all public holidays from db. Return array of start and end dates
	 *
	 */
	function public_holidays()
	{
		$this->load->model('booking_model');
		$query = $this->booking_model->get_public_holidays();
		$public_holidays = array();
		
		if ($query->num_rows() > 0)
		{
			foreach($query->result() as $row)
			{
				$public_holidays[] = array(
					'start_date'	=> date('d-m-Y', strtotime($row->start_date)),
					'end_date'		=> date('d-m-Y', strtotime($row->end_date))
				);
			}
		}
		
		return $public_holidays;
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Get the difference in days between two dates
	 *
	 */
	function date_difference($start, $end)
	{
		$start = strtotime($start);
		$end = strtotime($end);
		
		$diff = floor(($end - $start)/(60 * 60 * 24));
		
		return $diff;
	}
	
	
	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Check if given date is in range
	 *
	 */
	function check_in_range($start_date, $end_date, $date_from_user)
	{
		// Convert to timestamp
		$start_ts = strtotime($start_date);
		$end_ts = strtotime($end_date);
		$user_ts = strtotime($date_from_user);
		
		// Check that user date is between start & end
		return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
	}


	// ---------------------------------------------------------------------------------------------------------------
	/**
	 * Accomodation - Start Booking Form
	 *
	 */
	function accommodation_booking_form()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('site_id', 'Site ID', 'trim|numeric');
		$this->form_validation->set_rules('accommodation_ids', 'Accommodation ID', 'trim|numeric');
		$this->form_validation->set_rules('start_date', 'Please select an arrival date from the calendar', 'trim|required');
		$this->form_validation->set_rules('duration', 'Please select how long you wish to stay', 'trim|numeric|required');
		$this->form_validation->set_rules('total_guests', 'Please select the number of guests', 'trim|numeric|required');
		$this->form_validation->set_rules('total_price', 'Number of guests', 'trim|numeric');
	}
	
}

/* End of file accommodation.php */
/* Location: ./application/controllers/accommodation.php */