<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bookings extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 */
	public function index()
	{	
		$data['sites'] = $this->data['sites'];
		$data['current_site'] = $this->data['current_site'];
		
		$start = date('Y-m-d');
		// End is 2 weeks from now
		$end = date('Y-m-d', (strtotime("now") + (60 * 60 * 24 * 14)));
		
		$this->load->model('booking_model');
		$data['bookings'] = $this->booking_model->get_bookings_next_two_weeks($start, $end);
		
		$this->load->view('admin/bookings/index', $data);
	}
	
	public function overview()
	{
		$data['sites'] = $this->data['sites'];
		$data['current_site'] = $this->data['current_site'];
		
		if ($this->uri->segment(4) === FALSE || !is_numeric($this->uri->segment(4)))
		{
			redirect('admin/bookings/index');
		}
		else
		{
			$booking_id = $this->uri->segment(4);
		
			//Get Booking Details
			$this->load->model('booking_model');
			$data['booking_details'] = $this->booking_model->get_booking($booking_id);
			
			if ($data['booking_details']->num_rows() > 0)
			{
				$booking = $data['booking_details']->row();
				$accommodation_id = $booking->accommodation_ids;
				$contact_id = $booking->contact_id;
			}
			
			// Get Accommodation Details
			$data['accommodation_details'] = $this->booking_model->get_accommodation($accommodation_id);
			
			// Get Contact Details
			$data['contact_details'] = $this->booking_model->get_contact($contact_id);
			
			// Get Extras
			$data['extras'] = $this->booking_model->get_booked_extras($booking_id);
		
			$this->load->view('admin/bookings/overview', $data);
		}
	}
}

/* End of file bookings.php */
/* Location: ./application/controllers/admin/bookings.php */