$(function () {
	// Admin Forms
	if ($('form.admin-form').length > 0) {
		$('a.remove-photo').click(function () {
			var $link = $(this);
			
			$link.hide();
			$link.prev().hide();
			$link.next().removeClass('hidden');
			
			return false;
		});
	}
	
	// Delete
	$('a.delete').click(function () {
		var deleteRow = confirm("Are you sure you want to delete this?"),
			area = $(this).parents('table').attr('id'),
			id = $(this).parent().parent().data('id');
		
		if (deleteRow) {
			$(this).parent().parent().fadeOut(300);
			
			$.ajax({
				type: "POST",
				url: area + "/delete",
				data: "id=" + id
			});
		}
		return false;
	});
	
	// Change Site
	$('a.change-site').click(function () {
		var id = $(this).data("id"),
			view = location.pathname;
		
		$.ajax({
			type: "POST",
			url: "/bivouac/index.php/admin/sites/change_site",
			data: {id: id, "view": view},
			success: function (data) {
				window.location.reload();
			}
		});
		
		return false;
	});
	
	// jQuery UI Datepicker
	$("form:not(#pricing-form)").find(".date-input").datepicker({ 
		dateFormat: 'dd-mm-yy 08:00'
	});
	
	// jQuery UI Datepicker
	$("#pricing-form").find('input.date-input').datepicker({ 
		dateFormat: 'dd-mm-yy',
		minDate: 0
	});
	
	// Pricing Functions
	if ($('#pricing-form').length > 0) {
		// Add Price Range
		$('a#pricing-add').click(function () {
			$('tr.pricing-form-container').show();
			return false;
		});
	
		// Check start date for duplicate
		$('input#start_date').change(function () {
			var date = $(this).val();
			
			$.ajax({
				type: 'POST',
				url: '/bivouac/index.php/admin/pricing/start_date_check',
				data: {'start_date': date},
				success: function (data) {
					if (data == 'true') {
						$('ul.errors').html('<li class="start_date_error">That start date already exists!</li>');
					} else {
						$('ul.errors').find('li.start_date_error').hide();
					}
				}
			});
		});
	}
	
	// Public Holidays Functions
	if ($('#holidays-form').length > 0) {
		// Add Price Range
		$('a#holiday-add').click(function () {
			$('tr.holidays-form-container').show();
			return false;
		});
	}
	
	// Voucher Codes Functions
	if ($('#vouchers-form').length > 0) {
		// Add Price Range
		$('a#voucher-add').click(function () {
			$('tr.vouchers-form-container').show();
			return false;
		});
	}
	
	// Export reports
	if ($('a.export-xls').length > 0) {
		// Add Price Range
		$('a.export-xls').click(function () {
			var title = $(this).data('title'),
				model_function = $(this).data('model_function');
				
			$.ajax({
				url: '/bivouac/index.php/admin/reports/export_xls',
				data: {'report_title': title, 'model_function': model_function},
				dataType: 'json',
				type: 'POST',
				success: function (data) {
					$('#result').html("<a href='/bivouac/reports/" + data + "'>Download Report</a>");
				}
			});
			
			return false;
		});
	}

});