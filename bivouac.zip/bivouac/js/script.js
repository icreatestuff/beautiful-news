var weekdays = new Array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');

Date.prototype.age = function (at) {
    var value = new Date(this.getTime()),
    	age = at.getFullYear() - value.getFullYear();
    	
    value = value.setFullYear(at.getFullYear());
    
    if (at < value) { --age; }
    
    return age;
};

function get_available_accommodation() {
	var selectedDate = $('#start_date').val(),
		duration = $('#duration').val();

	// Get all accommodaiton available between start_date and end of duration
	$.ajax({
		url: '/bivouac/index.php/booking/get_available_accommodation',
		dataType: 'json',
		data: {'duration': duration, 'start_date': selectedDate},
		type: 'post',
		success: function (data) {
			// Add accommodation to list
			$('#accommodation').html(data);
		}
	});
}

function update_prices(quantity, nights, price) {
	var extrasPrice = $('span#extras-price'),
		totalPrice = $('span#total-price'),
		itemPrice;
		
	if (nights) {
		itemPrice = Math.round(quantity * nights * price);
	} else {
		itemPrice = Math.round(quantity * price);
	}
	
	// Add itemPrice to current extra dna total prices
	extrasPrice.text(itemPrice + parseInt(extrasPrice.text()));
	totalPrice.text(itemPrice + parseInt(totalPrice.text()));
	
	// Add total_price to form
	$('input#price').val(totalPrice.text());
}

function bed_tooltip() {	
	$('#accommodation-calendar').find('td.available').live('mouseover', function (event) {
		var beds = $(this).attr('title');
			
		if (typeof beds !== 'undefined' && beds !== false) {
			$('#tooltip_hint').remove();
			$('body').append('<div id="tooltip_hint"></div>');
			
			$('#tooltip_hint').css({
				top: event.pageY + 15,
				left: event.pageX - 30
			}).html("There are <strong>" + beds + "</strong> beds available on this day.").show();
		}
		
		return false;
	});
	
	$('#accommodation-calendar').find('td.available').live('mouseout', function (event) {
		$('#tooltip_hint').remove();
	});
}

function accom_calendar(id, unavDates, bedDates, totalBeds, isBunkBarn) {
	var url = '/bivouac/index.php/accommodation/get_durations',
		pHolidays = new Array();
	
	if (isBunkBarn) {
		url = '/bivouac/index.php/accommodation/get_bunk_barn_durations';
	}
	
	// Get Public Holiday dates
	$.ajax({
		url: '/bivouac/index.php/accommodation/get_public_holidays',
		dataType: 'json',
		type: 'post',
		success: function (data) {
			$.each(data, function (key, val) {
				var pHoliday = val['start_date'].split("-"),
					pHolidayArray = new Array(pHoliday[0], pHoliday[1], pHoliday[2]);
					
				pHolidays.push(pHolidayArray);			
			});

			
			// Initialize Calendar
			$('#accommodation-calendar').datepicker({
				minDate: 0,
				onSelect: function(dateText, inst) {
					var selectedDate = inst.selectedDay + "-" + (inst.selectedMonth + 1) + "-" + inst.selectedYear;
					
					// Put selected date into form field
					$('input#start_date').val(selectedDate);
					
					// Get all duration options and prices based on selected arrival date
					$.ajax({
						url: url,
						dataType: 'json',
						data: {id: id, 'start_date': selectedDate},
						type: 'post',
						success: function (data) {
							var options = "<option value=''>Please select how long you wish to stay</option>";
							
							$.each(data.durations, function (key, val) {
								var nights = val[0],
									price = val[1],
									start = val[2],
									end = val[3];
									
								if (isBunkBarn) {
									if (nights === 1) {
										options += "<option value=" + nights + " data-price=" + price + ">" + nights + " night - £" + price + "pppn (" + start + " - " + end + ")</option>";
									} else {
										options += "<option value=" + nights + " data-price=" + price + ">" + nights + " nights - £" + price + "pppn (" + start + " - " + end + ")</option>";
									}
								} else {
									if (nights === 1) {
										options += "<option value=" + nights + " data-price=" + price + ">" + nights + " night - £" + price + " (" + start + " - " + end + ")</option>";
									} else {
										options += "<option value=" + nights + " data-price=" + price + ">" + nights + " nights - £" + price + " (" + start + " - " + end + ")</option>";
									}
								}
							});
							
							$('#duration').html(options);
						}
					});
				},
				beforeShowDay: function (date) {
					var day = date.getDay(),
						month = date.getMonth(),
						year = date.getFullYear(),
						date = date.getDate(),
						today = new Date(),						
						currentDate = new Date();
						
					
					// Set dates in the past to unavailable
					if (currentDate < today) {
						return [false, 'unavailable'];
					}
					
					// Process unavailable/already booked dates	
					for (i = 0; i < unavDates.length; i++) {
						if (month == unavDates[i][1] - 1 && date == unavDates[i][0] && year == unavDates[i][2]) {
							return [false, 'unavailable'];
						}
					}
			    
				    // Process number of beds tooltip - For bunk barns only
				    if (isBunkBarn) {
						for (i = 0; i < bedDates.length; i++) {
							if (month == bedDates[i][0][1] - 1 && date == bedDates[i][0][0] && year == bedDates[i][0][2]) {
								return [true, 'book-in-date available', bedDates[i][1]];
							}
						}
				    	 
						return [true, 'book-in-date available', totalBeds]; 
				    } else {
				    	// Run through public holiday dates. Add class if current date is in holidays array.
						for (i = 0; i < pHolidays.length; i++) {	
							var holDate = pHolidays[i][0],
								holMonth = pHolidays[i][1] - 1,
								holYear = pHolidays[i][2],
								nextDay = parseInt(pHolidays[i][0]) + 1,
								nextDate = new Date(holYear, holMonth, nextDay),
								testDate = new Date(2011, 11, 26 + 1);
																							
							if (month == holMonth && date == holDate && year == holYear) {
								if (weekdays[day - 1] == 'Friday') {
									return [true, 'book-in-date available public_holiday'];
								} else {
									return [true, 'available public_holiday'];
								}
							} else if (month == nextDate.getMonth() && date == nextDate.getDate() && year == nextDate.getFullYear()) {
								if (weekdays[day - 1] == 'Tuesday') {
									return [true, 'book-in-date available'];
								}
							}
						}
				    
				    	if (weekdays[day - 1] == 'Monday' || weekdays[day - 1] == 'Friday') {
							return [true, 'book-in-date available'];
						}	
							
						return [true, 'available'];
				    }
				}
			});
		}
	});
}

$(function () {
	// General Calendar
	if ($('#calendar').length > 0) {
		$('#calendar').datepicker({
			minDate: 0,
			beforeShowDay: function (date) {
				var day = date.getDay();
			
				if (weekdays[day - 1] == 'Monday' || weekdays[day - 1] == 'Friday') {
					return [true, 'book-in-date available'];
				} else {
					return [true, 'available'];
				}
			},
			onSelect: function(dateText, inst) {
				var selectedDate = inst.selectedDay + "-" + (inst.selectedMonth + 1) + "-" + inst.selectedYear,
					d = new Date(dateText),
					options;
				
				// Put selected date into form field
				$('input#start_date').val(selectedDate);
				
				// If selectedDate == Monday show 4, 7, 11, 14
				// If selectedDate == Friday show 3, 7, 10, 14
				if (d.getDay() == 1) {
					options = "<option value='0'>Please select how long you would like to stay</option><option value='4'>4 nights</option><option value='7'>7 nights</option><option value='11'>11 nights</option><option value='14'>14 nights</option>";
				} else if (d.getDay() == 5) {
					options = "<option value='0'>Please select how long you would like to stay</option><option value='3'>3 nights</option><option value='7'>7 nights</option><option value='10'>10 nights</option><option value='14'>14 nights</option>";
				}
				
				$('#duration').html(options);
			}	
		});
		
		// When a duration is selected, find what accommodation is available.
		$('#duration').change(get_available_accommodation);
		
		$('input[type=radio]').live('change', function () {
			// Set #total_price of selected accommodation
			$('#total_price').val($(this).parents('li').data('price'));
			
			// Set guest numbers dropdown from data attribute
			var options,
				i = 1,
				sleeps = parseInt($(this).parents('li').data('sleeps'));
			
			console.log(sleeps);
			
			for (i=1; i<=sleeps; i++) {
				options += "<option value='" + i + "'>" + i + "</option>";
			}
			
			$('#total_guests').html(options);
		});
	}

	
	// Accommodation Unit specific calendar
	if ($('#accommodation-calendar').length > 0) {
		// Get all unavailable dates for this accommodation
		var id = $('#accommodation-calendar').data('accom-id'),
			unavDates = new Array(),
			bedDates = new Array(),
			url = '/bivouac/index.php/accommodation/get_booked_dates',
			isBunkBarn = false,
			totalBeds = 0;
		
		// Set option if accommodation is a bunk barn	
		if ($('#accommodation-calendar').data('type') === 'Bunk Barn') {
			isBunkBarn = true;
			bed_tooltip();
		}
		
		// Process all unavailable dates and those with remaining beds
		$.ajax({
			url: url,
			dataType: 'json',
			data: {id: id, 'bunk_barn': isBunkBarn},
			type: 'post',
			success: function (data) {
				totalBeds = data.beds;
			
				if (data.response == true) {
					$.each(data.dates, function (key, val) {
						if (isBunkBarn) {
							var date = val[0].split("-"),
							dateArray = new Array(date[0], date[1], date[2]),
							remainingBeds = new Array(dateArray, val[1]);
							
							bedDates.push(remainingBeds);
							
							if (remainingBeds[1] === 0) {
								unavDates.push(dateArray);
							}
						} else {
							var date = val[0].split("-"),
								dateArray = new Array(date[0], date[1], date[2]);
								
							unavDates.push(dateArray);
						}
					});
				}
				
				accom_calendar(id, unavDates, bedDates, totalBeds, isBunkBarn);
			}
		});
		
		// Add current total price into form field
		$('select#duration').bind('blur change', function () {
			$('input#total_price').val($(this).find('option:selected').data('price'));
		});	
	}
	
	// Process live Price -> Extras Page
	if ($('#extras').length > 0) {
		$('input[type=checkbox], select').change(function () {
			var extra = $(this).parent(),
				quantity = extra.find('.extra_quantity').val(),
				price = extra.find('.extra_price').val(),
				nights = extra.find('.extra_nights').val(); 		
				
			if (extra.find('.extra_quantity').is('input:checkbox')) {
				if (extra.find('.extra_quantity').is(':checked')) {
					// Checkbox that is checked
					update_prices(quantity, 0, price);
				} else {
					update_prices(quantity, 0, -price);
				}
			} else {
				// prevval data attribute exists and is greater than 0
				if ($(this).data('prevval') > 0) {
					var prev = $(this).data('prevval');
					
					if ($(this).hasClass('extra_quantity')) {
						quantity = -prev;
					} else {
						nights = -prev;
					}
					
					update_prices(quantity, nights, price);
					
					// If current val == 0 then just remove from total
					// else remove and then add new quantity to price
					if ($(this).val() != 0) {
						if ($(this).hasClass('extra_quantity')) {
							quantity = extra.find('.extra_quantity').val();
						} else {
							nights = extra.find('.extra_nights').val();
						}
						
						console.log("Q=" + quantity + "N=" + nights);
					
						update_prices(quantity, nights, price);
					}
				} else {
					update_prices(quantity, nights, price);
				}
				
				// Set previous value to data
				$(this).data('prevval', $(this).val());
			}
		});
	}
	
	// Process Contact Page
	if ($('#contact').length > 0) {
		var dob,
			dobValid = true,
			dobDay,
			dobMonth,
			dobYear,
			dobString = "";
	
		// Calculate age from DOB dropdown options
		$('select.dob').change(function () {
			// Only calculate age if there are no '--' values in dob options
			$('select.dob').each(function (index) {
				if ($(this).val() === "--") {
					dobValid = false;
					return false;
				} else {
					// Create date string
					if (index === 0) {
						dobDay = $(this).val();
					} else if (index === 1) {
						dobMonth = $(this).val();
					} else {
						dobYear = $(this).val();
					}
				}
			});
			
			if (dobDay && dobMonth && dobYear) {
				dobString = dobMonth + "/" + dobDay + "/" + dobYear;
			}
			
			if (dobValid) {
				dob = new Date(Date.parse(dobString));
	
				if (dob.age(new Date()) < 18) {
				    alert("Sorry you are not old enough to make a booking at the Bivouac. You must be 18 years or older.");
				    
				    // Hide submit button if it is visible
				    if ($('#submit').is(":visible")) {
				    	$('#submit').hide();
				    }
				}
			}
		});	
		
		// T & C's must be checked in order to continue.
		$('input#terms_and_conditions').change(function () {
			if ($(this).is(':checked')) {
				$('#submit').show();
			} else {
				$('#submit').hide();
			}
		});
		
			
	}
});